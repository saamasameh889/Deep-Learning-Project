import numpy as np

def predict_class(model, X):
    y_pred = model.predict(X)
    class_index = np.argmax(y_pred)
    return f"Class {class_index} (Confidence: {np.max(y_pred):.2f})"
