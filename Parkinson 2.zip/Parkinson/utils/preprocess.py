import numpy as np

def preprocess_input(features_str):
    features = np.array([float(x.strip()) for x in features_str.split(',')])
    # Reshape for RNN: (1, time_steps, features)
    return features.reshape(1, -1, 1)
