import os
import pandas as pd
from sklearn.preprocessing import StandardScaler

# Constants
samples_per_subject = 26
num_features = 26

def trim_df(df):
    trim_len = (df.shape[0] // samples_per_subject) * samples_per_subject
    return df.iloc[:trim_len]

def load_and_preprocess_data(dataset_folder="Parkinson DATASET/Extracted"):
    # File paths
    train_path = os.path.join(dataset_folder, "train_data.txt")
    test_path  = os.path.join(dataset_folder, "test_data.txt")

    # Load raw data
    train_df = pd.read_csv(train_path, header=None)
    test_df  = pd.read_csv(test_path, header=None)

    # Assign column names
    train_columns = ['subject_id'] + [f'f{i+1}' for i in range(num_features)] + ['UPDRS', 'class']
    test_columns  = ['subject_id'] + [f'f{i+1}' for i in range(num_features)] + ['UPDRS']
    train_df.columns = train_columns
    test_df.columns  = test_columns

    # Convert datatypes
    train_df['subject_id'] = train_df['subject_id'].astype(int)
    train_df['UPDRS']      = train_df['UPDRS'].astype(float)
    train_df['class']      = train_df['class'].astype(int)
    test_df['subject_id']  = test_df['subject_id'].astype(int)
    test_df['UPDRS']       = test_df['UPDRS'].astype(float)

    # Trim to full subjects
    train_df = trim_df(train_df)
    test_df  = trim_df(test_df)

    # Prepare and scale features
    scaler = StandardScaler()
    X_train = train_df[[f'f{i+1}' for i in range(num_features)]].values
    X_test  = test_df[[f'f{i+1}' for i in range(num_features)]].values

    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled  = scaler.transform(X_test)

    # Reshape for sequence models
    num_train_subjects = train_df.shape[0] // samples_per_subject
    num_test_subjects  = test_df.shape[0] // samples_per_subject
    X_train_seq = X_train_scaled.reshape(num_train_subjects, samples_per_subject, num_features)
    X_test_seq  = X_test_scaled.reshape(num_test_subjects, samples_per_subject, num_features)

    # Prepare targets
    y_train_class = train_df['class'].values[::samples_per_subject]
    y_train_updrs = train_df['UPDRS'].values[::samples_per_subject]
    y_test_updrs  = test_df['UPDRS'].values[::samples_per_subject]

    return X_train_seq, X_test_seq, y_train_class, y_train_updrs, y_test_updrs
